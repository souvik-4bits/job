<?php


namespace App\Http\Controllers\Api;


use App\Helpers\APIHelpers;
use App\Http\Controllers\Controller;
use App\Models\customer;
use App\Models\point_transaction;
use Illuminate\Http\Request;
use Throwable;
use Validator;

class pointsController extends Controller
{
        //Add Points to customer
    public function addPoints(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => 'required|numeric',
            'point' => 'required|numeric',
            'transaction_type' => 'required|string',

        ]);
        if ($validator->fails()) {
            return response(['message' => 'Validation errors', 'errors' => $validator->errors()->first(), 'status' => false], 422);
        }

        try {
            customer::findorfail($request['customer_id']);
        }
        catch (\Throwable $throwable)
        {
            $response = APIHelpers::createAPIResponse(true, 'Customer does Not Exist', '');
            return response(['response' => $response], 404);
        }
        try {
            $request['status']="credit";
            $pointTransaction = point_transaction::create($request->toarray());

        } catch (Throwable $throwable) {
            $response=APIHelpers::createAPIResponse(true,'Points cannot added this moment' ,'');
            return response(['response'=>$response],200);
        }

            $response=APIHelpers::createAPIResponse('false',$request['point'].' points Added SuccessFully','');
            return response(['response'=>$response],200);

    }

        //Void Points of a customer

    public function voidPoints($id,Request $request)
    {
        //Transaction Id

        $request['id']=$id;

        $validator = Validator::make($request->all(), [
            'id' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            return response(['message' => 'Validation errors', 'errors' =>$validator->errors()->first(), 'status' => false], 422);
        }
        try {
            point_transaction::findorfail($request['id'])->update(['status'=>'void']);
        }
        catch (Throwable $th)
        {
            $response=APIHelpers::createAPIResponse(true,'Transaction Id Does not Exist','');
            return response(['response'=>$response],404);

        }

        $response=APIHelpers::createAPIResponse(false,' points Voided Successfully','');
        return response(['response'=>$response],200);

    }



}
